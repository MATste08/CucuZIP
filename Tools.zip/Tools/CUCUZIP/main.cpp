#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <vector>
#include <queue>
#include <string>
#include <fstream>
#include <algorithm>

static uint64_t UpdateFNV1a(uint64_t hash, const uint8_t* data, size_t len) {
    const uint64_t prime = 1099511628211ULL;
    for (size_t i = 0; i < len; ++i) {
        hash ^= static_cast<uint64_t>(data[i]);
        hash *= prime;
    }
    return hash;
}

struct BitWriter {
    std::vector<uint8_t> bytes;
    uint8_t currentByte = 0;
    int bitCount = 0;

    void WriteBit(int bit) {
        if (bit) currentByte |= (1u << bitCount);
        bitCount++;
        if (bitCount == 8) {
            bytes.push_back(currentByte);
            currentByte = 0;
            bitCount = 0;
        }
    }

    void WriteBits(uint32_t value, int numBits) {
        for (int i = 0; i < numBits; ++i) {
            WriteBit((value >> i) & 1u);
        }
    }

    void Flush() {
        if (bitCount > 0) {
            bytes.push_back(currentByte);
            currentByte = 0;
            bitCount = 0;
        }
    }
};

struct BitReader {
    const uint8_t* data;
    size_t size;
    size_t bytePos = 0;
    int bitPos = 0;

    BitReader(const uint8_t* d, size_t s) : data(d), size(s) {}

    int ReadBit() {
        if (bytePos >= size) return -1;
        int bit = (data[bytePos] >> bitPos) & 1;
        bitPos++;
        if (bitPos == 8) {
            bitPos = 0;
            bytePos++;
        }
        return bit;
    }

    bool ReadBits(int numBits, uint32_t& outVal) {
        outVal = 0;
        for (int i = 0; i < numBits; ++i) {
            int b = ReadBit();
            if (b < 0) return false;
            if (b) outVal |= (1u << i);
        }
        return true;
    }
};

struct HuffNode {
    int symbol;
    uint32_t freq;
    int left;
    int right;
};

struct HuffCode {
    uint32_t bits = 0;
    uint8_t len = 0;
};

static void BuildCodeTable(const std::vector<HuffNode>& nodes, int idx, uint32_t code, uint8_t depth, HuffCode table[257]) {
    if (idx < 0) return;
    if (nodes[idx].symbol >= 0) {
        table[nodes[idx].symbol].bits = code;
        table[nodes[idx].symbol].len = (depth == 0) ? 1 : depth;
        return;
    }
    BuildCodeTable(nodes, nodes[idx].left, code, depth + 1, table);
    BuildCodeTable(nodes, nodes[idx].right, code | (1u << depth), depth + 1, table);
}

static int BuildHuffmanTree(const uint32_t freq[257], std::vector<HuffNode>& nodes) {
    nodes.clear();
    nodes.reserve(515);

    struct HeapItem {
        uint32_t freq;
        int nodeIdx;
        bool operator>(const HeapItem& other) const {
            if (freq != other.freq) return freq > other.freq;
            return nodeIdx > other.nodeIdx;
        }
    };

    std::priority_queue<HeapItem, std::vector<HeapItem>, std::greater<HeapItem>> pq;
    for (int i = 0; i < 257; ++i) {
        if (freq[i] > 0) {
            int idx = static_cast<int>(nodes.size());
            nodes.push_back({i, freq[i], -1, -1});
            pq.push({freq[i], idx});
        }
    }

    if (pq.empty()) return -1;
    if (pq.size() == 1) {
        HeapItem only = pq.top();
        int rootIdx = static_cast<int>(nodes.size());
        nodes.push_back({-1, only.freq, only.nodeIdx, -1});
        return rootIdx;
    }

    while (pq.size() > 1) {
        HeapItem a = pq.top(); pq.pop();
        HeapItem b = pq.top(); pq.pop();
        int parentIdx = static_cast<int>(nodes.size());
        nodes.push_back({-1, a.freq + b.freq, a.nodeIdx, b.nodeIdx});
        pq.push({a.freq + b.freq, parentIdx});
    }
    return pq.top().nodeIdx;
}

struct LZToken {
    bool isMatch;
    uint8_t literal;
    uint16_t dist;
    uint16_t length;
};

static std::vector<uint8_t> CompressBlock(const uint8_t* src, size_t len, bool& outCompressed) {
    const size_t WINDOW_SIZE = 32768;
    const size_t MIN_MATCH = 3;
    const size_t MAX_MATCH = 258;
    const size_t HASH_BITS = 15;
    const size_t HASH_SIZE = 1 << HASH_BITS;

    std::vector<int32_t> head(HASH_SIZE, -1);
    std::vector<int32_t> prev(WINDOW_SIZE, -1);

    auto calcHash = [&](size_t pos) -> uint32_t {
        uint32_t v = (static_cast<uint32_t>(src[pos]) << 16) |
                     (static_cast<uint32_t>(src[pos + 1]) << 8) |
                     static_cast<uint32_t>(src[pos + 2]);
        return ((v * 2654435761u) >> (32 - HASH_BITS)) & (HASH_SIZE - 1);
    };

    std::vector<LZToken> tokens;
    tokens.reserve(len / 2);
    uint32_t freq[257] = {0};

    size_t pos = 0;
    while (pos < len) {
        size_t bestLen = 0;
        size_t bestDist = 0;

        if (pos + MIN_MATCH <= len) {
            uint32_t h = calcHash(pos);
            int32_t matchPos = head[h];
            head[h] = static_cast<int32_t>(pos);
            prev[pos & (WINDOW_SIZE - 1)] = matchPos;

            int chainCount = 0;
            size_t maxAllowedLen = std::min(MAX_MATCH, len - pos);

            while (matchPos >= 0 && (pos - static_cast<size_t>(matchPos)) <= WINDOW_SIZE && chainCount < 64) {
                if (src[matchPos + bestLen] == src[pos + bestLen] && src[matchPos] == src[pos]) {
                    size_t mLen = 0;
                    while (mLen < maxAllowedLen && src[matchPos + mLen] == src[pos + mLen]) {
                        mLen++;
                    }
                    if (mLen >= MIN_MATCH && mLen > bestLen) {
                        bestLen = mLen;
                        bestDist = pos - static_cast<size_t>(matchPos);
                        if (bestLen == maxAllowedLen) break;
                    }
                }
                matchPos = prev[matchPos & (WINDOW_SIZE - 1)];
                chainCount++;
            }
        }

        if (bestLen >= MIN_MATCH) {
            tokens.push_back({true, 0, static_cast<uint16_t>(bestDist), static_cast<uint16_t>(bestLen)});
            freq[256]++;
            size_t endSkip = std::min(pos + bestLen, len >= MIN_MATCH ? len - MIN_MATCH + 1 : 0);
            for (size_t k = pos + 1; k < endSkip; ++k) {
                uint32_t h = calcHash(k);
                prev[k & (WINDOW_SIZE - 1)] = head[h];
                head[h] = static_cast<int32_t>(k);
            }
            pos += bestLen;
        } else {
            tokens.push_back({false, src[pos], 0, 0});
            freq[src[pos]]++;
            pos++;
        }
    }

    std::vector<HuffNode> nodes;
    int root = BuildHuffmanTree(freq, nodes);
    HuffCode table[257];
    BuildCodeTable(nodes, root, 0, 0, table);

    BitWriter bw;
    uint16_t activeSymbols = 0;
    for (int i = 0; i < 257; ++i) {
        if (freq[i] > 0) activeSymbols++;
    }

    bw.WriteBits(activeSymbols, 9);
    for (int i = 0; i < 257; ++i) {
        if (freq[i] > 0) {
            bw.WriteBits(static_cast<uint32_t>(i), 9);
            bw.WriteBits(freq[i], 24);
        }
    }

    bw.WriteBits(static_cast<uint32_t>(tokens.size()), 24);

    for (const auto& t : tokens) {
        if (!t.isMatch) {
            bw.WriteBits(table[t.literal].bits, table[t.literal].len);
        } else {
            bw.WriteBits(table[256].bits, table[256].len);
            bw.WriteBits(static_cast<uint32_t>(t.dist - 1), 15);
            bw.WriteBits(static_cast<uint32_t>(t.length - MIN_MATCH), 8);
        }
    }
    bw.Flush();

    if (bw.bytes.size() >= len) {
        outCompressed = false;
        return std::vector<uint8_t>(src, src + len);
    }

    outCompressed = true;
    return bw.bytes;
}

static bool DecompressBlock(const uint8_t* compData, size_t compSize, size_t origSize, bool isCompressed, std::vector<uint8_t>& outBlock) {
    if (!isCompressed) {
        if (compSize != origSize) return false;
        outBlock.assign(compData, compData + compSize);
        return true;
    }

    BitReader br(compData, compSize);
    uint32_t activeSymbols = 0;
    if (!br.ReadBits(9, activeSymbols) || activeSymbols == 0 || activeSymbols > 257) return false;

    uint32_t freq[257] = {0};
    for (uint32_t i = 0; i < activeSymbols; ++i) {
        uint32_t sym = 0, f = 0;
        if (!br.ReadBits(9, sym) || !br.ReadBits(24, f) || sym >= 257) return false;
        freq[sym] = f;
    }

    uint32_t tokenCount = 0;
    if (!br.ReadBits(24, tokenCount)) return false;

    std::vector<HuffNode> nodes;
    int root = BuildHuffmanTree(freq, nodes);
    if (root < 0) return false;

    outBlock.clear();
    outBlock.reserve(origSize);

    for (uint32_t t = 0; t < tokenCount; ++t) {
        int curr = root;
        while (nodes[curr].symbol < 0) {
            int bit = br.ReadBit();
            if (bit < 0) return false;
            curr = (bit == 0) ? nodes[curr].left : nodes[curr].right;
            if (curr < 0) return false;
        }

        int sym = nodes[curr].symbol;
        if (sym < 256) {
            outBlock.push_back(static_cast<uint8_t>(sym));
        } else {
            uint32_t distMinus1 = 0, lenMinus3 = 0;
            if (!br.ReadBits(15, distMinus1) || !br.ReadBits(8, lenMinus3)) return false;
            size_t dist = static_cast<size_t>(distMinus1) + 1;
            size_t matchLen = static_cast<size_t>(lenMinus3) + 3;
            if (dist > outBlock.size()) return false;

            size_t copyStart = outBlock.size() - dist;
            for (size_t k = 0; k < matchLen; ++k) {
                outBlock.push_back(outBlock[copyStart + k]);
            }
        }
    }

    return outBlock.size() == origSize;
}

static bool CompressFileCUC(const std::string& inPath, const std::string& outPath) {
    std::ifstream in(inPath, std::ios::binary);
    if (!in) return false;

    std::ofstream out(outPath, std::ios::binary);
    if (!out) return false;

    const char magic[4] = {'C', 'U', 'C', '1'};
    uint64_t totalOrigSize = 0;
    uint64_t checksum = 14695981039346656037ULL;
    out.write(magic, 4);
    out.write(reinterpret_cast<const char*>(&totalOrigSize), 8);
    out.write(reinterpret_cast<const char*>(&checksum), 8);

    const size_t BLOCK_SIZE = 512 * 1024;
    std::vector<uint8_t> buffer(BLOCK_SIZE);

    while (in) {
        in.read(reinterpret_cast<char*>(buffer.data()), BLOCK_SIZE);
        std::streamsize bytesRead = in.gcount();
        if (bytesRead <= 0) break;

        size_t chunkLen = static_cast<size_t>(bytesRead);
        totalOrigSize += chunkLen;
        checksum = UpdateFNV1a(checksum, buffer.data(), chunkLen);

        bool isCompressed = false;
        std::vector<uint8_t> packed = CompressBlock(buffer.data(), chunkLen, isCompressed);

        uint8_t flag = isCompressed ? 1 : 0;
        uint32_t origBlockSz = static_cast<uint32_t>(chunkLen);
        uint32_t storedSz = static_cast<uint32_t>(packed.size());

        out.write(reinterpret_cast<const char*>(&flag), 1);
        out.write(reinterpret_cast<const char*>(&origBlockSz), 4);
        out.write(reinterpret_cast<const char*>(&storedSz), 4);
        out.write(reinterpret_cast<const char*>(packed.data()), storedSz);
    }

    out.seekp(4, std::ios::beg);
    out.write(reinterpret_cast<const char*>(&totalOrigSize), 8);
    out.write(reinterpret_cast<const char*>(&checksum), 8);
    return true;
}

static bool DecompressFileCUC(const std::string& inPath, const std::string& outPath) {
    std::ifstream in(inPath, std::ios::binary);
    if (!in) return false;

    char magic[4] = {0};
    uint64_t expectedOrigSize = 0;
    uint64_t expectedChecksum = 0;

    in.read(magic, 4);
    in.read(reinterpret_cast<char*>(&expectedOrigSize), 8);
    in.read(reinterpret_cast<char*>(&expectedChecksum), 8);

    if (!in || std::memcmp(magic, "CUC1", 4) != 0) return false;

    std::ofstream out(outPath, std::ios::binary);
    if (!out) return false;

    uint64_t restoredSize = 0;
    uint64_t checksum = 14695981039346656037ULL;
    std::vector<uint8_t> compBuf;
    std::vector<uint8_t> rawBlock;

    while (in.peek() != EOF) {
        uint8_t flag = 0;
        uint32_t origBlockSz = 0;
        uint32_t storedSz = 0;

        in.read(reinterpret_cast<char*>(&flag), 1);
        in.read(reinterpret_cast<char*>(&origBlockSz), 4);
        in.read(reinterpret_cast<char*>(&storedSz), 4);
        if (!in) return false;

        compBuf.resize(storedSz);
        in.read(reinterpret_cast<char*>(compBuf.data()), storedSz);
        if (!in) return false;

        if (!DecompressBlock(compBuf.data(), storedSz, origBlockSz, (flag == 1), rawBlock)) {
            return false;
        }

        out.write(reinterpret_cast<const char*>(rawBlock.data()), rawBlock.size());
        restoredSize += rawBlock.size();
        checksum = UpdateFNV1a(checksum, rawBlock.data(), rawBlock.size());
    }

    return (restoredSize == expectedOrigSize && checksum == expectedChecksum);
}

static std::string BuildRestorePath(const std::string& cucPath) {
    std::string base = cucPath;
    if (base.size() > 4 && base.substr(base.size() - 4) == ".cuc") {
        base = base.substr(0, base.size() - 4);
    }
    std::ifstream probe(base, std::ios::binary);
    if (!probe.good()) return base;

    size_t dot = base.find_last_of('.');
    size_t slash = base.find_last_of("\\/");
    if (dot != std::string::npos && (slash == std::string::npos || dot > slash)) {
        base.insert(dot, "_restored");
    } else {
        base += "_restored";
    }
    return base;
}

int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int) {
    int argc = 0;
    LPWSTR* argvW = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (!argvW || argc < 3) {
        if (argvW) LocalFree(argvW);
        return 0;
    }

    auto wideToUtf8 = [](LPCWSTR ws) -> std::string {
        int needed = WideCharToMultiByte(CP_ACP, 0, ws, -1, NULL, 0, NULL, NULL);
        if (needed <= 1) return "";
        std::string out(needed - 1, '\0');
        WideCharToMultiByte(CP_ACP, 0, ws, -1, &out[0], needed, NULL, NULL);
        return out;
    };

    std::string mode = wideToUtf8(argvW[1]);
    std::string target = wideToUtf8(argvW[2]);
    LocalFree(argvW);

    if (mode == "--compress") {
        CompressFileCUC(target, target + ".cuc");
    } else if (mode == "--decompress") {
        DecompressFileCUC(target, BuildRestorePath(target));
    }
    return 0;
}
