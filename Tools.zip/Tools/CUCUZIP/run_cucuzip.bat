@echo off
setlocal
cd /d "%~dp0"

set "EXE_PATH=%~dp0CUCUZIP.exe"
if not exist "%EXE_PATH%" set "EXE_PATH=%~dp0bin\Debug\CUCUZIP.exe"

if not exist "%EXE_PATH%" (
    msg * "CUCUZIP.exe was not found next to run_cucuzip.bat."
    exit /b 1
)

if "%~1"=="" (
    "%EXE_PATH%" --register --popup
    exit /b %errorlevel%
)

if /i "%~1"=="--register" (
    "%EXE_PATH%" --register --popup
    exit /b %errorlevel%
)

"%EXE_PATH%" --auto "%~1" --loader
exit /b %errorlevel%