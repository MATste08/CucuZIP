Option Explicit

Dim fso, shell, scriptDir, batPath, targetArg
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
batPath = fso.BuildPath(scriptDir, "run_cucuzip.bat")

If Not fso.FileExists(batPath) Then
    MsgBox "Missing run_cucuzip.bat next to run_hidden.vbs.", vbCritical, "CUCUZIP"
    WScript.Quit 1
End If

targetArg = ""
If WScript.Arguments.Count > 0 Then
    targetArg = " """ & WScript.Arguments(0) & """"
End If

shell.Run """" & batPath & """" & targetArg, 0, False